#!/bin/bash
# Safe shutdown for MiSTer: flush writes, try to mark filesystems clean,
# report each drive's exFAT clean/dirty state, then halt.
# Does NOT stop bluetoothd - a clean bluetoothd exit with RememberPowered=true
# leaves the BT adapter permanently off (MiSTer-devel/Scripts_MiSTer#36).

show() { # title, message, height
  if [ -z "$NODIALOG" ] && command -v dialog >/dev/null 2>&1; then
    clear
    TERM=linux dialog --backtitle "MiSTer Shutdown" --title "$1" --infobox "$2" "${3:-9}" 46 2>/dev/null
  else
    echo; echo "  =========================================="; echo "   $1"; echo "  =========================================="
    echo -e "$2" | sed 's/^/   /'; echo "  =========================================="
  fi
}

part_of() { # block device behind a mount point (resolves /dev/root)
  local d maj min name
  d=$(stat -c %d "$1" 2>/dev/null) || return
  maj=$(( (d >> 8) & 0xfff )); min=$(( (d & 0xff) | ((d >> 12) & 0xfff00) ))
  name=$(basename "$(readlink -f "/sys/dev/block/$maj:$min" 2>/dev/null)")
  [ -n "$name" ] && [ "$name" != "$maj:$min" ] || return
  [ -b "/dev/$name" ] || mknod "/dev/$name" b "$maj" "$min" 2>/dev/null
  [ -b "/dev/$name" ] && echo "/dev/$name"
}

vol_state() { # on-disk exFAT VolumeFlags of a partition
  local p=$1 sig flags
  sig=$(od -An -c -j3 -N8 "$p" 2>/dev/null | tr -d ' \n')
  [ "$sig" = "EXFAT" ] || { echo "n/a (not exFAT)"; return; }
  flags=$(od -An -tu1 -j106 -N1 "$p" | tr -d ' ')
  if (( flags & 4 )); then echo "MEDIA FAILURE"
  elif (( flags & 2 )); then echo "DIRTY"
  else echo "clean"; fi
}

show "Shutting down" "\n   Flushing writes to storage...\n\n   Do NOT power off yet."
mounts=()
for m in /media/usb[0-9]* /media/fat; do [ -d "$m" ] && mountpoint -q "$m" && mounts+=("$m"); done
sync
for m in "${mounts[@]}"; do mount -o remount,ro "$m" 2>/dev/null; done
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null   # read flags from the card, not cache
sleep 2

report="" dirty=0
for m in "${mounts[@]}"; do
  p=$(part_of "$m"); s=$( [ -n "$p" ] && vol_state "$p" || echo "unknown")
  report="$report\n   $(printf '%-12s %s' "$m" "$s")"
  [[ $s == DIRTY || $s == MEDIA* ]] && dirty=1
done
if [ $dirty -eq 0 ]; then note="   Windows will NOT complain."
else note="   DIRTY: Windows will offer to scan.\n   Data is synced; scan is optional."; fi

show "SAFE TO POWER OFF" "\n      ***  SAFE TO POWER OFF  ***\n$report\n\n$note" $(( 10 + ${#mounts[@]} + dirty ))
sleep 1
halt -f
