#!/bin/bash
# Safe shutdown for MiSTer: flush writes, try to mark filesystems clean,
# report each drive's exFAT clean/dirty state, then halt.
# Does NOT stop bluetoothd - a clean bluetoothd exit with RememberPowered=true
# leaves the BT adapter permanently off (MiSTer-devel/Scripts_MiSTer#36).

# --- Console Mode support -------------------------------------------------
# Console Mode runs scripts with its UI on screen, which hides the script's
# terminal. When that happens, messages are drawn straight on the screen with
# the ss1fb helper (installed by SS1 Tool in Scripts/.ss1tool/).
SS1FB="$(dirname "$(readlink -f "$0")")/.ss1tool/ss1fb"
[ -x "$SS1FB" ] || SS1FB=/media/fat/Scripts/.ss1tool/ss1fb
cm_hidden() {
  [ -z "$NODIALOG" ] && [ -x "$SS1FB" ] && [ -e /dev/fb0 ] || return 1
  [ -n "$SS1_FORCE_FB" ] && return 0
  local p=$PPID i=0
  while [ -n "$p" ] && [ "$p" -gt 1 ] && [ $i -lt 8 ]; do
    case "$(cat "/proc/$p/comm" 2>/dev/null)" in script_runner*) return 0 ;; esac
    p=$(awk '{print $4}' "/proc/$p/stat" 2>/dev/null); i=$((i+1))
  done
  [ ! -t 1 ]
}
CM_HIDDEN=0; cm_hidden && CM_HIDDEN=1
fbshow() { "$SS1FB" -title "$1" -tone "${2:-info}" 2>/dev/null; }  # body lines on stdin
fbcolor() { # prefix result lines: PASS/clean green, FAIL red, WARN/INFO amber
  sed -E -e 's/^[[:space:]]+//' \
    -e '/(FAIL|MEDIA FAILURE|DIRTY|ERROR)/s/^/- /' \
    -e '/^- /!{/(WARN|UNVERIFIED|INFO|SKIP|older)/s/^/! /}' \
    -e '/^[-!] /!{/(PASS|clean|OK)/s/^/+ /}'
}
# --------------------------------------------------------------------------

show() { # title, message, height, tone
  if [ "$CM_HIDDEN" = 1 ]; then
    echo -e "$2" | grep -v '\*\*\*' | fbcolor | fbshow "$1" "${4:-info}"
    return
  fi
  if [ -z "$NODIALOG" ] && command -v dialog >/dev/null 2>&1; then
    clear
    TERM=linux dialog --backtitle "MiSTer Shutdown" --title "$1" --infobox "$2" "${3:-9}" 46 2>/dev/null
  else
    echo; echo "  =========================================="; echo "   $1"; echo "  =========================================="
    echo -e "$2" | sed 's/^/   /'; echo "  =========================================="
  fi
}

part_of() { # block device behind a mount point (resolves /dev/root)
  local d maj min name
  d=$(stat -c %d "$1" 2>/dev/null) || return
  maj=$(( (d >> 8) & 0xfff )); min=$(( (d & 0xff) | ((d >> 12) & 0xfff00) ))
  name=$(basename "$(readlink -f "/sys/dev/block/$maj:$min" 2>/dev/null)")
  [ -n "$name" ] && [ "$name" != "$maj:$min" ] || return
  [ -b "/dev/$name" ] || mknod "/dev/$name" b "$maj" "$min" 2>/dev/null
  [ -b "/dev/$name" ] && echo "/dev/$name"
}

vol_state() { # on-disk exFAT VolumeFlags of a partition
  local p=$1 sig flags
  sig=$(od -An -c -j3 -N8 "$p" 2>/dev/null | tr -d ' \n')
  [ "$sig" = "EXFAT" ] || { echo "n/a (not exFAT)"; return; }
  flags=$(od -An -tu1 -j106 -N1 "$p" | tr -d ' ')
  if (( flags & 4 )); then echo "MEDIA FAILURE"
  elif (( flags & 2 )); then echo "DIRTY"
  else echo "clean"; fi
}

show "Shutting down" "\n   Flushing writes to storage...\n\n   Do NOT power off yet." 9 warn
mounts=()
for m in /media/usb[0-9]* /media/fat; do [ -d "$m" ] && mountpoint -q "$m" && mounts+=("$m"); done
sync
for m in "${mounts[@]}"; do mount -o remount,ro "$m" 2>/dev/null; done
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null   # read flags from the card, not cache
sleep 2

report="" dirty=0
for m in "${mounts[@]}"; do
  p=$(part_of "$m"); s=$( [ -n "$p" ] && vol_state "$p" || echo "unknown")
  report="$report\n   $(printf '%-12s %s' "$m" "$s")"
  [[ $s == DIRTY || $s == MEDIA* ]] && dirty=1
done
if [ $dirty -eq 0 ]; then note="   All data written to storage.\n   Windows will NOT complain."
else note="   DIRTY: Windows will offer to scan.\n   Data is synced; scan is optional."; fi

show "SAFE TO POWER OFF" "\n      ***  SAFE TO POWER OFF  ***\n$report\n\n$note" $(( 10 + ${#mounts[@]} + dirty )) good
sleep 1
halt -f
