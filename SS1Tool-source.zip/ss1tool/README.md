# SS1 Tool

Windows companion for the SuperStation One (MiSTer). Run `SS1Tool.exe`; it opens in your web browser (local only, 127.0.0.1) and connects to the SuperStation over SSH (default login root / 1).

## Features
- **Connect / status**: saved devices (name, IP, user; password not stored, blank = 1), plus kernel, /MiSTer.version, Console Mode, Samba, update_linux, scripts, free space.
- **Setup**: install the SS1 scripts (sd_integrity, shutdown, ss1_debug_report); enable Samba at boot and start it; install the latest update_all.sh and set downloader.ini to the MiSTer-devel distribution with `update_linux = false`; remove the faulty fix_sd_overlap tool; save your own ScreenScraper login and TheGamesDB key for Console Mode, with the installed values detected and shown under each field.
- **Remote**: reload menu core, reboot, safe shutdown, SSH terminal, open the Samba share, a remote controller (D-pad, A/B/X/Y, Select, Start, OSD; hold-to-press) and a remote keyboard (on-screen keys and live key capture), via a virtual USB controller and keyboard on the MiSTer.
- **Files**: two-pane file manager with a drive picker on each side; copy or move between the SD card and NVMe/USB on the MiSTer itself, plus upload, download (folders as zip), rename, delete, new folder. System folders are protected.
- **MiSTer Settings**: edit MiSTer.ini, downloader.ini, Console Mode's config.ini and every ini in ConsoleMode/themeconfig (including section_groups). SS1 HDMI fix (comments out selected HDMI settings, restorable). Backups are stored on the PC next to SS1Tool.exe, one folder per ini file (MiSTer.ini, downloader.ini, ConsoleMode.ini, ConsoleMode themeconfig\section_groups\Arcade.ini, ...): back up one file or all of them with an optional name and/or date-time stamp, restore, show in Explorer or delete. The tool also backs up automatically before every change.
- **SD Diagnostics**: quick check, "Will Windows complain?", partition table, exFAT boot region, kernel errors, on the SD card or NVMe. Deep scans open in a terminal.
- **Debug Report**: runs ss1_debug_report.sh (including Console Mode config.ini and all themeconfig/section_groups files), shows the findings and opens a Save As window to store the report anywhere on your PC for Taki / the mods.
- **Flash SD Card**: downloads the latest official SuperStation One SD Card Installer and writes it to an SD/USB card (removable disks only, requires administrator, verified after writing).

## Notes
- Windows SmartScreen may warn because the exe is unsigned: More info > Run anyway.
- Terminal features use Windows' built-in OpenSSH client.
- Build: Go 1.22. First build the keyboard helper: `CGO_ENABLED=0 GOOS=linux GOARCH=arm GOARM=7 go build -ldflags "-s -w" -o bin/ss1kbd_arm ./kbdhelper`, then `GOOS=windows GOARCH=amd64 go build -ldflags "-s -w" -o SS1Tool.exe .`
