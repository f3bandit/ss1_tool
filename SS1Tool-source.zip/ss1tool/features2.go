package main

import (
	"bufio"
	"bytes"
	"crypto/md5"
	_ "embed"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

func registerRoutes2(mux *http.ServeMux) {
	h := func(p string, f http.HandlerFunc) { mux.HandleFunc(p, guard(f)) }
	h("/api/kbd", apiKbd)
	h("/api/devices", apiDevices)
	h("/api/devices/delete", apiDeviceDelete)
	h("/api/kbd/stop", func(w http.ResponseWriter, r *http.Request) { kbdStop(); writeJSON(w, map[string]bool{"ok": true}) })
	h("/api/drives", apiDrives)
	h("/api/fs/transfer", apiTransfer)
	h("/api/fs/transfer/progress", apiTransferProgress)
	h("/api/ini/backups", apiIniBackups)
	h("/api/ini/backup", apiIniBackup)
	h("/api/ini/restore", apiIniRestore)
	h("/api/ini/backup-delete", apiIniBackupDelete)
	h("/api/ini/backup-show", apiIniBackupShow)
	h("/api/ini/list", apiIniList)
	h("/api/ini/backup-all", apiIniBackupAll)
}

// ================================================================ remote keyboard

//go:embed bin/ss1kbd_arm
var kbdHelper []byte

const kbdRemote = "/tmp/ss1kbd"

var (
	kbdMu    sync.Mutex
	kbdSess  *ssh.Session
	kbdIn    io.WriteCloser
	kbdAlive bool
)

func kbdStop() {
	kbdMu.Lock()
	defer kbdMu.Unlock()
	if kbdIn != nil {
		_, _ = io.WriteString(kbdIn, "r\nq\n")
		_ = kbdIn.Close()
	}
	if kbdSess != nil {
		_ = kbdSess.Close()
	}
	kbdSess, kbdIn, kbdAlive = nil, nil, false
}

// kbdStart uploads the helper (if changed) and starts it; caller holds kbdMu.
func kbdStart() error {
	sum := md5.Sum(kbdHelper)
	want := hex.EncodeToString(sum[:])
	have, _ := run("md5sum " + kbdRemote + " 2>/dev/null | cut -d' ' -f1")
	if strings.TrimSpace(have) != want {
		if err := upload(kbdRemote, bytes.NewReader(kbdHelper), "755"); err != nil {
			return err
		}
	}
	s, err := session()
	if err != nil {
		return err
	}
	in, err := s.StdinPipe()
	if err != nil {
		s.Close()
		return err
	}
	out, err := s.StdoutPipe()
	if err != nil {
		s.Close()
		return err
	}
	if err := s.Start(kbdRemote); err != nil {
		s.Close()
		return err
	}
	ready := make(chan string, 1)
	go func() {
		sc := bufio.NewScanner(out)
		first := true
		for sc.Scan() {
			if first {
				ready <- sc.Text()
				first = false
			}
		}
		kbdMu.Lock()
		if kbdSess == s {
			kbdAlive = false
		}
		kbdMu.Unlock()
	}()
	select {
	case line := <-ready:
		if line != "ready" {
			s.Close()
			return errors.New("keyboard helper: " + line)
		}
	case <-time.After(10 * time.Second):
		s.Close()
		return errors.New("keyboard helper did not start")
	}
	kbdSess, kbdIn, kbdAlive = s, in, true
	return nil
}

var kbdOps = map[string]bool{"d": true, "u": true, "t": true, "s": true, "r": true, "pd": true, "pu": true, "pt": true}

// gamepad: A=304 B=305 Y=307 X=308 LB=310 RB=311 Select=314 Start=315 Guide=316, D-pad 544-547
var padCodes = map[int]bool{304: true, 305: true, 307: true, 308: true, 310: true, 311: true,
	314: true, 315: true, 316: true, 544: true, 545: true, 546: true, 547: true}

func apiKbd(w http.ResponseWriter, r *http.Request) {
	if !needConn(w) {
		return
	}
	var req struct {
		Cmds [][2]any `json:"cmds"`
	}
	if err := readJSON(r, &req); err != nil || len(req.Cmds) == 0 || len(req.Cmds) > 2000 {
		fail(w, 400, "bad request")
		return
	}
	var b strings.Builder
	for _, c := range req.Cmds {
		op, _ := c[0].(string)
		code, _ := c[1].(float64)
		isPad := strings.HasPrefix(op, "p")
		if !kbdOps[op] || (isPad && !padCodes[int(code)]) || (!isPad && op != "r" && (code < 1 || code > 255)) {
			fail(w, 400, "bad key command")
			return
		}
		fmt.Fprintf(&b, "%s %d\n", op, int(code))
	}
	kbdMu.Lock()
	defer kbdMu.Unlock()
	for attempt := 0; attempt < 2; attempt++ {
		if !kbdAlive {
			if kbdSess != nil {
				_ = kbdSess.Close()
			}
			if err := kbdStart(); err != nil {
				fail(w, 502, err.Error())
				return
			}
		}
		if _, err := io.WriteString(kbdIn, b.String()); err == nil {
			writeJSON(w, map[string]bool{"ok": true})
			return
		}
		kbdAlive = false
	}
	fail(w, 502, "keyboard connection lost")
}

// ================================================================ drives

type drive struct {
	Path  string `json:"path"`
	FS    string `json:"fs"`
	Label string `json:"label"`
	Free  string `json:"free"`
	Size  string `json:"size"`
}

func listDrives() ([]drive, error) {
	out, err := run(`awk '$2=="/media/fat" || $2 ~ /^\/media\/usb[0-9]+$/ {print $2" "$3}' /proc/mounts | while read m t; do echo "$m $t $(df -h "$m" | awk 'NR==2{print $4" "$2}')"; done`)
	if err != nil {
		return nil, err
	}
	d := []drive{}
	for _, l := range strings.Split(strings.TrimSpace(out), "\n") {
		f := strings.Fields(l)
		if len(f) < 2 {
			continue
		}
		x := drive{Path: f[0], FS: f[1]}
		if len(f) >= 4 {
			x.Free, x.Size = f[2], f[3]
		}
		if x.Path == fat {
			x.Label = "SD card"
		} else {
			x.Label = "USB/NVMe " + strings.TrimPrefix(x.Path, "/media/")
		}
		d = append(d, x)
	}
	sort.Slice(d, func(i, j int) bool { return d[i].Path < d[j].Path })
	return d, nil
}

func apiDrives(w http.ResponseWriter, r *http.Request) {
	if !needConn(w) {
		return
	}
	d, err := listDrives()
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	writeJSON(w, d)
}

// ================================================================ copy / move between drives

type transferJob struct {
	Running  bool     `json:"running"`
	Op       string   `json:"op"`
	DoneKB   int64    `json:"done_kb"`
	TotalKB  int64    `json:"total_kb"`
	Current  string   `json:"current"`
	Log      []string `json:"log"`
	Error    string   `json:"error"`
	Finished bool     `json:"finished"`
}

var (
	tjMu sync.Mutex
	tj   transferJob
)

func tjSet(f func(*transferJob)) { tjMu.Lock(); f(&tj); tjMu.Unlock() }

func apiTransferProgress(w http.ResponseWriter, r *http.Request) {
	tjMu.Lock()
	j := tj
	j.Log = append([]string(nil), tj.Log...)
	tjMu.Unlock()
	writeJSON(w, j)
}

func duKB(p string) int64 {
	out, err := run("du -sk -- " + shq(p) + " 2>/dev/null | cut -f1")
	if err != nil {
		return 0
	}
	var n int64
	fmt.Sscan(strings.TrimSpace(out), &n)
	return n
}

func apiTransfer(w http.ResponseWriter, r *http.Request) {
	if !needConn(w) {
		return
	}
	var req struct {
		Op        string
		Items     []string
		Dest      string
		Overwrite bool
	}
	if err := readJSON(r, &req); err != nil || (req.Op != "copy" && req.Op != "move") || len(req.Items) == 0 {
		fail(w, 400, "bad request")
		return
	}
	dest, ok := cleanRemote(req.Dest)
	if !ok || dest == "/media" {
		fail(w, 400, "bad destination")
		return
	}
	var items []string
	for _, it := range req.Items {
		p, ok := cleanRemote(it)
		if !ok || isProtected(p) {
			fail(w, 400, "can't "+req.Op+" "+it)
			return
		}
		if dest == p || strings.HasPrefix(dest+"/", p+"/") {
			fail(w, 400, "can't "+req.Op+" a folder into itself")
			return
		}
		if path.Dir(p) == dest {
			fail(w, 400, path.Base(p)+" is already in that folder")
			return
		}
		items = append(items, p)
	}
	tjMu.Lock()
	if tj.Running {
		tjMu.Unlock()
		fail(w, 409, "a copy/move is already running")
		return
	}
	tj = transferJob{Running: true, Op: req.Op, Current: "Measuring..."}
	tjMu.Unlock()
	go runTransfer(req.Op, items, dest, req.Overwrite)
	writeJSON(w, map[string]bool{"ok": true})
}

func runTransfer(op string, items []string, dest string, overwrite bool) {
	defer tjSet(func(j *transferJob) { j.Running, j.Finished, j.Current = false, true, "" })
	var total int64
	for _, it := range items {
		total += duKB(it)
	}
	tjSet(func(j *transferJob) { j.TotalKB = total })
	var done int64
	verb := map[string]string{"copy": "Copied", "move": "Moved"}[op]
	for _, src := range items {
		name := path.Base(src)
		target := dest + "/" + name
		size := duKB(src)
		tjSet(func(j *transferJob) { j.Current = name })
		exists, _ := run("[ -e " + shq(target) + " ] && echo yes")
		if strings.TrimSpace(exists) == "yes" {
			if !overwrite {
				tjSet(func(j *transferJob) { j.Log = append(j.Log, "Skipped "+name+" (already exists)") })
				done += size
				continue
			}
			if _, err := run("rm -rf -- " + shq(target)); err != nil {
				tjSet(func(j *transferJob) { j.Log = append(j.Log, "FAILED "+name+": could not replace existing") })
				continue
			}
		}
		cmd := "cp -r -- " + shq(src) + " " + shq(dest+"/")
		if op == "move" {
			cmd = "mv -- " + shq(src) + " " + shq(dest+"/")
		}
		stop := make(chan struct{})
		go func(base int64) { // progress: measure the destination while copying
			for {
				select {
				case <-stop:
					return
				case <-time.After(1500 * time.Millisecond):
					n := duKB(target)
					tjSet(func(j *transferJob) { j.DoneKB = base + n })
				}
			}
		}(done)
		out, err := run(cmd + " && sync")
		close(stop)
		done += size
		tjSet(func(j *transferJob) {
			j.DoneKB = done
			if err != nil {
				msg := strings.TrimSpace(out)
				if msg == "" {
					msg = err.Error()
				}
				j.Log = append(j.Log, "FAILED "+name+": "+msg)
				j.Error = "some items failed"
			} else {
				j.Log = append(j.Log, verb+" "+name)
			}
		})
	}
}

// ================================================================ named ini backups (stored on the PC)

// Backups live next to SS1Tool.exe, one folder per ini file:
//
//	MiSTer.ini\  downloader.ini\  ConsoleMode.ini\  ConsoleMode themeconfig\section_groups\Arcade.ini\ ...
type iniInfo struct {
	Path   string `json:"id"`
	Label  string `json:"label"`
	Folder string `json:"folder"`
}

var themeIniRe = regexp.MustCompile(`^/media/fat/ConsoleMode/themeconfig/(section_groups/)?[A-Za-z0-9 _.()&+-]+\.ini$`)

// resolveIni accepts a remote path (or the legacy keys mister/downloader/cmconfig).
func resolveIni(id string) (iniInfo, bool) {
	if p, ok := iniFiles[id]; ok {
		id = p
	}
	switch id {
	case fat + "/MiSTer.ini":
		return iniInfo{id, "MiSTer.ini", "MiSTer.ini"}, true
	case fat + "/downloader.ini":
		return iniInfo{id, "downloader.ini", "downloader.ini"}, true
	case cmDir + "/config.ini":
		return iniInfo{id, "Console Mode settings (config.ini)", "ConsoleMode.ini"}, true
	}
	if themeIniRe.MatchString(id) && !strings.Contains(id, "..") {
		rel := strings.TrimPrefix(id, cmDir+"/themeconfig/")
		return iniInfo{id, "Theme: " + rel, filepath.Join("ConsoleMode themeconfig", filepath.FromSlash(rel))}, true
	}
	return iniInfo{}, false
}

var backupNameRe = regexp.MustCompile(`^[A-Za-z0-9._-]{1,80}\.ini$`)

func exeDir() string {
	exe, err := os.Executable()
	if err != nil {
		return "."
	}
	if r, err := filepath.EvalSymlinks(exe); err == nil {
		exe = r
	}
	return filepath.Dir(exe)
}

func backupDirFor(p string) string {
	if info, ok := resolveIni(p); ok {
		return filepath.Join(exeDir(), info.Folder)
	}
	return filepath.Join(exeDir(), "other ini")
}

// listInis returns the fixed ini files plus every ini in ConsoleMode/themeconfig (incl. section_groups).
func listInis() []iniInfo {
	res := []iniInfo{}
	for _, p := range []string{fat + "/MiSTer.ini", fat + "/downloader.ini", cmDir + "/config.ini"} {
		info, _ := resolveIni(p)
		res = append(res, info)
	}
	out, _ := run(`for f in /media/fat/ConsoleMode/themeconfig/*.ini /media/fat/ConsoleMode/themeconfig/section_groups/*.ini; do [ -f "$f" ] && echo "$f"; done`)
	for _, l := range strings.Split(strings.TrimSpace(out), "\n") {
		if info, ok := resolveIni(strings.TrimSpace(l)); ok {
			res = append(res, info)
		}
	}
	return res
}

func apiIniList(w http.ResponseWriter, r *http.Request) {
	if !needConn(w) {
		return
	}
	writeJSON(w, listInis())
}

func apiIniBackupAll(w http.ResponseWriter, r *http.Request) {
	if !needConn(w) {
		return
	}
	var req struct {
		Name  string
		Stamp bool
	}
	_ = readJSON(r, &req)
	if cleanLabel(req.Name) == "" && !req.Stamp {
		fail(w, 400, "enter a name or tick 'add date and time'")
		return
	}
	var done, failed []string
	for _, f := range listInis() {
		b, err := makeBackup(f.Path, req.Name, req.Stamp)
		switch {
		case err != nil:
			failed = append(failed, f.Label+": "+err.Error())
		case b != "":
			done = append(done, f.Label)
		}
	}
	msg := fmt.Sprintf("Backed up %d ini file(s) to %s", len(done), exeDir())
	if len(failed) > 0 {
		msg += "\nFailed:\n" + strings.Join(failed, "\n")
	}
	writeJSON(w, map[string]any{"ok": len(failed) == 0, "message": msg})
}

func cleanLabel(s string) string {
	s = strings.TrimSpace(s)
	s = regexp.MustCompile(`\s+`).ReplaceAllString(s, "_")
	s = regexp.MustCompile(`[^A-Za-z0-9_-]`).ReplaceAllString(s, "")
	if len(s) > 40 {
		s = s[:40]
	}
	return s
}

// makeBackup downloads remote file p into its backup folder on the PC as
// <label>[_<timestamp>].ini (never overwrites). Returns "" if p doesn't exist.
func makeBackup(p, label string, stamp bool) (string, error) {
	label = cleanLabel(label)
	if label == "" && !stamp {
		return "", errors.New("enter a name or tick 'add date and time'")
	}
	name := label
	if stamp {
		ts := time.Now().Format("2006-01-02_15-04-05")
		if name == "" {
			name = ts
		} else {
			name += "_" + ts
		}
	}
	if out, _ := run("[ -f " + shq(p) + " ] && echo yes"); strings.TrimSpace(out) != "yes" {
		return "", nil
	}
	var buf bytes.Buffer
	if err := runTo("cat "+shq(p), &buf); err != nil {
		return "", fmt.Errorf("could not read %s - nothing changed", p)
	}
	dir := backupDirFor(p)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", fmt.Errorf("cannot create backup folder %s: %v - nothing changed", dir, err)
	}
	dst := filepath.Join(dir, name+".ini")
	for i := 1; ; i++ {
		if _, err := os.Stat(dst); os.IsNotExist(err) {
			break
		}
		dst = filepath.Join(dir, fmt.Sprintf("%s-%d.ini", name, i))
	}
	if err := os.WriteFile(dst, buf.Bytes(), 0o644); err != nil {
		return "", fmt.Errorf("cannot write backup %s: %v - nothing changed", dst, err)
	}
	return dst, nil
}

// backupFile is the automatic backup taken before the tool changes a file.
func backupFile(p string) (string, error) { return makeBackup(p, "auto", true) }

func iniParam(r *http.Request, file string) (string, bool) {
	if file == "" {
		file = r.URL.Query().Get("file")
	}
	info, ok := resolveIni(file)
	return info.Path, ok
}

func apiIniBackups(w http.ResponseWriter, r *http.Request) {
	p, ok := iniParam(r, "")
	if !ok {
		fail(w, 400, "unknown file")
		return
	}
	dir := backupDirFor(p)
	type bk struct {
		Name  string `json:"name"`
		Path  string `json:"path"`
		Size  int64  `json:"size"`
		MTime int64  `json:"mtime"`
	}
	list := []bk{}
	ents, _ := os.ReadDir(dir)
	for _, e := range ents {
		if e.IsDir() || !strings.HasSuffix(strings.ToLower(e.Name()), ".ini") {
			continue
		}
		if fi, err := e.Info(); err == nil {
			list = append(list, bk{Name: e.Name(), Path: filepath.Join(dir, e.Name()), Size: fi.Size(), MTime: fi.ModTime().Unix()})
		}
	}
	sort.Slice(list, func(i, j int) bool { return list[i].MTime > list[j].MTime })
	writeJSON(w, map[string]any{"dir": dir, "backups": list})
}

func apiIniBackup(w http.ResponseWriter, r *http.Request) {
	if !needConn(w) {
		return
	}
	var req struct {
		File, Name string
		Stamp      bool
	}
	_ = readJSON(r, &req)
	p, ok := iniParam(r, req.File)
	if !ok {
		fail(w, 400, "unknown file")
		return
	}
	b, err := makeBackup(p, req.Name, req.Stamp)
	if err != nil {
		fail(w, 400, err.Error())
		return
	}
	if b == "" {
		fail(w, 404, p+" does not exist on the SuperStation - nothing to back up")
		return
	}
	writeJSON(w, map[string]any{"ok": true, "message": "Backup saved: " + b})
}

func backupPath(file, name string) (string, string, bool) {
	info, ok := resolveIni(file)
	if !ok || !backupNameRe.MatchString(name) || strings.Contains(name, "..") {
		return "", "", false
	}
	return info.Path, filepath.Join(backupDirFor(info.Path), name), true
}

func apiIniRestore(w http.ResponseWriter, r *http.Request) {
	if !needConn(w) {
		return
	}
	var req struct{ File, Name string }
	_ = readJSON(r, &req)
	p, b, ok := backupPath(req.File, req.Name)
	if !ok {
		fail(w, 400, "bad backup")
		return
	}
	data, err := os.ReadFile(b)
	if err != nil {
		fail(w, 404, "backup not found: "+b)
		return
	}
	safety, err := makeBackup(p, "before-restore", true)
	if err != nil {
		fail(w, 502, err.Error())
		return
	}
	if err := upload(p, bytes.NewReader(data), "644"); err != nil {
		fail(w, 502, "restore failed: "+err.Error())
		return
	}
	msg := "Restored " + p + " from " + req.Name
	if safety != "" {
		msg += "\nPrevious version saved as: " + filepath.Base(safety)
	}
	writeJSON(w, map[string]any{"ok": true, "message": msg})
}

func apiIniBackupDelete(w http.ResponseWriter, r *http.Request) {
	var req struct{ File, Name string }
	_ = readJSON(r, &req)
	_, b, ok := backupPath(req.File, req.Name)
	if !ok {
		fail(w, 400, "bad backup")
		return
	}
	if err := os.Remove(b); err != nil {
		fail(w, 500, err.Error())
		return
	}
	writeJSON(w, map[string]any{"ok": true})
}

// apiIniBackupShow opens Explorer on a backup file, or on the backup folder for a file type.
func apiIniBackupShow(w http.ResponseWriter, r *http.Request) {
	var req struct{ File, Name string }
	_ = readJSON(r, &req)
	if req.Name == "" {
		p, ok := iniParam(r, req.File)
		if !ok {
			fail(w, 400, "unknown file")
			return
		}
		dir := backupDirFor(p)
		_ = os.MkdirAll(dir, 0o755)
		openPath(dir)
		writeJSON(w, map[string]bool{"ok": true})
		return
	}
	_, b, ok := backupPath(req.File, req.Name)
	if !ok {
		fail(w, 400, "bad backup")
		return
	}
	revealFile(b)
	writeJSON(w, map[string]bool{"ok": true})
}

// ================================================================ saved devices

var devNameRe = regexp.MustCompile(`^[^<>"'\\]{1,40}$`)

func apiDevices(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		cfgMu.Lock()
		d := append([]Device{}, cfg.Devices...)
		cfgMu.Unlock()
		writeJSON(w, d)
		return
	}
	var req Device
	if err := readJSON(r, &req); err != nil {
		fail(w, 400, "bad request")
		return
	}
	req.Name, req.Host, req.User = strings.TrimSpace(req.Name), strings.TrimSpace(req.Host), strings.TrimSpace(req.User)
	if !devNameRe.MatchString(req.Name) {
		fail(w, 400, "enter a device name (up to 40 characters)")
		return
	}
	if !hostRe.MatchString(req.Host) {
		fail(w, 400, "enter a valid IP address first")
		return
	}
	if req.User == "" {
		req.User = "root"
	}
	cfgMu.Lock()
	replaced := false
	for i := range cfg.Devices {
		if strings.EqualFold(cfg.Devices[i].Name, req.Name) {
			cfg.Devices[i], replaced = req, true
		}
	}
	if !replaced {
		cfg.Devices = append(cfg.Devices, req)
	}
	sort.Slice(cfg.Devices, func(i, j int) bool {
		return strings.ToLower(cfg.Devices[i].Name) < strings.ToLower(cfg.Devices[j].Name)
	})
	cfgMu.Unlock()
	saveConfig()
	verb := "Saved"
	if replaced {
		verb = "Updated"
	}
	writeJSON(w, map[string]any{"ok": true, "message": verb + " device " + req.Name})
}

func apiDeviceDelete(w http.ResponseWriter, r *http.Request) {
	var req struct{ Name string }
	_ = readJSON(r, &req)
	cfgMu.Lock()
	out := cfg.Devices[:0]
	found := false
	for _, d := range cfg.Devices {
		if strings.EqualFold(d.Name, req.Name) {
			found = true
			continue
		}
		out = append(out, d)
	}
	cfg.Devices = out
	cfgMu.Unlock()
	if !found {
		fail(w, 404, "device not found")
		return
	}
	saveConfig()
	writeJSON(w, map[string]any{"ok": true})
}
