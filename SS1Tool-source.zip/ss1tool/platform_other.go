//go:build !windows

package main

import (
	"errors"
	"net/http"
	"os/exec"
)

func openBrowser(url string)    { _ = exec.Command("xdg-open", url).Start() }
func flashBusy() bool           { return false }
func startDetached(c *exec.Cmd) {}
func openPath(p string)         { _ = exec.Command("xdg-open", p).Start() }
func revealFile(p string)       { _ = exec.Command("xdg-open", p).Start() }

func openTerminal(host, user, remoteCmd string) error {
	return errors.New("terminal windows are only supported on Windows")
}

func saveFileDialog(defaultName string) (string, error) {
	return "", errors.New("no save dialog on this platform")
}

func windowsOnly(w http.ResponseWriter, r *http.Request) {
	fail(w, http.StatusNotImplemented, "SD card flashing is only available on Windows")
}

var (
	apiFlashDisks    = windowsOnly
	apiFlashAdmin    = windowsOnly
	apiFlashElevate  = windowsOnly
	apiFlashLatest   = windowsOnly
	apiFlashStart    = windowsOnly
	apiFlashProgress = windowsOnly
)
