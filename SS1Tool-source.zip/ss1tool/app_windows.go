package main

// Windows app shell: SS1 Tool runs as a normal Windows program (no console window), with an
// icon in the notification area (tray), one running copy at a time, its own app window, and
// error messages in a Windows message box.

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")

	pRegisterClassExW                        = user32.NewProc("RegisterClassExW")
	pCreateWindowExW                         = user32.NewProc("CreateWindowExW")
	pDefWindowProcW                          = user32.NewProc("DefWindowProcW")
	pGetMessageW                             = user32.NewProc("GetMessageW")
	pTranslateMessage                        = user32.NewProc("TranslateMessage")
	pDispatchMessageW                        = user32.NewProc("DispatchMessageW")
	pCreatePopupMenu                         = user32.NewProc("CreatePopupMenu")
	pAppendMenuW                             = user32.NewProc("AppendMenuW")
	pSetMenuDefaultItem                      = user32.NewProc("SetMenuDefaultItem")
	pTrackPopupMenu                          = user32.NewProc("TrackPopupMenu")
	pDestroyMenu                             = user32.NewProc("DestroyMenu")
	pSetForegroundWindow                     = user32.NewProc("SetForegroundWindow")
	pPostMessageW                            = user32.NewProc("PostMessageW")
	pGetCursorPos                            = user32.NewProc("GetCursorPos")
	pLoadImageW                              = user32.NewProc("LoadImageW")
	pGetSystemMetrics                        = user32.NewProc("GetSystemMetrics")
	pRegisterWindowMessageW                  = user32.NewProc("RegisterWindowMessageW")
	pMessageBoxW                             = user32.NewProc("MessageBoxW")
	pShellNotifyIconW                        = shell32.NewProc("Shell_NotifyIconW")
	pGetModuleHandleW                        = kernel32.NewProc("GetModuleHandleW")
	pCreateMutexW                            = kernel32.NewProc("CreateMutexW")
	pCloseHandle                             = kernel32.NewProc("CloseHandle")
	pSetCurrentProcessExplicitAppUserModelID = shell32.NewProc("SetCurrentProcessExplicitAppUserModelID")
)

const (
	wmApp          = 0x8000
	wmTray         = wmApp + 1
	wmNull         = 0x0000
	wmLButtonUp    = 0x0202
	wmLButtonDbl   = 0x0203
	wmRButtonUp    = 0x0205
	wmContextMenu  = 0x007B
	nimAdd         = 0
	nimModify      = 1
	nimDelete      = 2
	nifMessage     = 0x1
	nifIcon        = 0x2
	nifTip         = 0x4
	nifInfo        = 0x10
	niifInfo       = 0x1
	mfString       = 0x0
	mfGrayed       = 0x1
	mfSeparator    = 0x800
	tpmReturnCmd   = 0x0100
	tpmNoNotify    = 0x0080
	tpmRightButton = 0x0002
	cmdOpen        = 1
	cmdQuit        = 2
	mbOK           = 0x0
	mbYesNo        = 0x4
	mbIconError    = 0x10
	mbIconWarning  = 0x30
	mbIconInfo     = 0x40
	mbDefButton2   = 0x100
	idYes          = 6
	appMutexName   = `Local\SS1Tool.f3bandit`
	appUserModelID = "f3bandit.SS1Tool"
)

type notifyIconData struct {
	CbSize           uint32
	HWnd             uintptr
	UID              uint32
	UFlags           uint32
	UCallbackMessage uint32
	HIcon            uintptr
	SzTip            [128]uint16
	DwState          uint32
	DwStateMask      uint32
	SzInfo           [256]uint16
	UVersion         uint32
	SzInfoTitle      [64]uint16
	DwInfoFlags      uint32
	GuidItem         [16]byte
	HBalloonIcon     uintptr
}

type wndClassEx struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}

type winMsg struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	PtX     int32
	PtY     int32
	Private uint32
}

var (
	trayMu      sync.Mutex
	trayNID     notifyIconData
	trayOn      bool
	trayURL     string
	taskbarMsg  uintptr
	appMutex    uintptr
	exitHooksMu sync.Mutex
	exitHooks   []func()
)

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

func copyU16(dst []uint16, s string) {
	u := syscall.StringToUTF16(s)
	if len(u) > len(dst) {
		u = append(u[:len(dst)-1], 0)
	}
	copy(dst, u)
}

// msgBox shows a Windows message box and returns the button pressed.
func msgBox(title, text string, flags uintptr) int {
	r, _, _ := pMessageBoxW.Call(0, uintptr(unsafe.Pointer(u16(text))), uintptr(unsafe.Pointer(u16(title))), flags|0x00010000 /*MB_SETFOREGROUND*/)
	return int(r)
}

// fatal reports a startup problem the user can see (there's no console window) and exits.
func fatal(msg string) {
	msgBox("SS1 Tool", "SS1 Tool couldn't start.\n\n"+msg, mbOK|mbIconError)
	appExit(1)
}

func onExit(f func()) { exitHooksMu.Lock(); exitHooks = append(exitHooks, f); exitHooksMu.Unlock() }

// appExit removes the tray icon and the running-instance note before the process ends.
func appExit(code int) {
	exitHooksMu.Lock()
	hooks := exitHooks
	exitHooks = nil
	exitHooksMu.Unlock()
	for _, f := range hooks {
		f()
	}
	os.Exit(code)
}

func instanceFile() string { return filepath.Join(filepath.Dir(configPath()), "instance.json") }

// singleInstance makes sure only one SS1 Tool runs. If another copy is already running,
// it opens that copy's window and returns false. A restart (update, run as administrator)
// waits for the previous copy to close first.
func singleInstance() bool {
	if os.Getenv("SS1TOOL_HANDOFF") != "" {
		// Started by the updater, which closes as soon as this copy reports in, so don't wait
		// for it. Holding the mutex handle keeps "one copy" in force after the old copy exits.
		h, _, _ := pCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(u16(appMutexName))))
		appMutex = h
		return true
	}
	restart := false
	for _, a := range os.Args[1:] {
		if a == "--restart" {
			restart = true
		}
	}
	deadline := time.Now().Add(10 * time.Second)
	for {
		h, _, err := pCreateMutexW.Call(0, 0, uintptr(unsafe.Pointer(u16(appMutexName))))
		exists := err == syscall.Errno(183) || err == syscall.Errno(5) // ALREADY_EXISTS / ACCESS_DENIED (other copy runs elevated)
		if h != 0 && !exists {
			appMutex = h
			return true
		}
		if h != 0 {
			pCloseHandle.Call(h)
		}
		if restart && time.Now().Before(deadline) {
			time.Sleep(250 * time.Millisecond)
			continue
		}
		break
	}
	if restart { // the old copy didn't close; run anyway rather than leave the user with nothing
		return true
	}
	var inst struct{ URL string }
	if b, err := os.ReadFile(instanceFile()); err == nil && json.Unmarshal(b, &inst) == nil && strings.HasPrefix(inst.URL, "http://127.0.0.1:") {
		openBrowser(inst.URL)
		return false
	}
	return true // no note from the other copy: start normally
}

func writeInstance(url string) {
	b, _ := json.Marshal(map[string]any{"url": url, "pid": os.Getpid(), "version": appVersion})
	_ = os.MkdirAll(filepath.Dir(instanceFile()), 0o755)
	_ = os.WriteFile(instanceFile(), b, 0o600)
	onExit(func() {
		var inst struct{ PID int }
		if b, err := os.ReadFile(instanceFile()); err == nil && json.Unmarshal(b, &inst) == nil && inst.PID == os.Getpid() {
			_ = os.Remove(instanceFile())
		}
	})
}

// appStart sets up the Windows side once the local server is listening. It returns false
// when another copy is already running (this copy should exit).
func appStart(url string) bool {
	pSetCurrentProcessExplicitAppUserModelID.Call(uintptr(unsafe.Pointer(u16(appUserModelID))))
	trayURL = url
	writeInstance(url)
	go trayLoop()
	return true
}

func trayIcon() uintptr {
	hinst, _, _ := pGetModuleHandleW.Call(0)
	cx, _, _ := pGetSystemMetrics.Call(49) // SM_CXSMICON
	cy, _, _ := pGetSystemMetrics.Call(50)
	h, _, _ := pLoadImageW.Call(hinst, 1 /* group icon 1 */, 1 /* IMAGE_ICON */, cx, cy, 0)
	return h
}

func trayAdd(first bool) {
	trayMu.Lock()
	defer trayMu.Unlock()
	trayNID.UFlags = nifMessage | nifIcon | nifTip
	copyU16(trayNID.SzTip[:], "SS1 Tool "+appVersion)
	pShellNotifyIconW.Call(nimAdd, uintptr(unsafe.Pointer(&trayNID)))
	trayOn = true
	if first {
		cfgMu.Lock()
		shown := cfg.TrayTipShown
		cfg.TrayTipShown = true
		cfgMu.Unlock()
		if !shown {
			saveConfig()
			n := trayNID
			n.UFlags = nifInfo
			copyU16(n.SzInfoTitle[:], "SS1 Tool is running")
			copyU16(n.SzInfo[:], "SS1 Tool stays here so long jobs like backups can finish. Click the icon to open it, or right-click to quit.")
			n.DwInfoFlags = niifInfo
			pShellNotifyIconW.Call(nimModify, uintptr(unsafe.Pointer(&n)))
		}
	}
}

func trayRemove() {
	trayMu.Lock()
	defer trayMu.Unlock()
	if trayOn {
		pShellNotifyIconW.Call(nimDelete, uintptr(unsafe.Pointer(&trayNID)))
		trayOn = false
	}
}

func trayMenu(hwnd uintptr) {
	m, _, _ := pCreatePopupMenu.Call()
	defer pDestroyMenu.Call(m)
	pAppendMenuW.Call(m, mfString|mfGrayed, 0, uintptr(unsafe.Pointer(u16("SS1 Tool "+appVersion))))
	pAppendMenuW.Call(m, mfSeparator, 0, 0)
	pAppendMenuW.Call(m, mfString, cmdOpen, uintptr(unsafe.Pointer(u16("Open SS1 Tool"))))
	pAppendMenuW.Call(m, mfString, cmdQuit, uintptr(unsafe.Pointer(u16("Quit"))))
	pSetMenuDefaultItem.Call(m, cmdOpen, 0)
	var pt struct{ X, Y int32 }
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	pSetForegroundWindow.Call(hwnd)
	cmd, _, _ := pTrackPopupMenu.Call(m, tpmReturnCmd|tpmNoNotify|tpmRightButton, uintptr(pt.X), uintptr(pt.Y), 0, hwnd, 0)
	pPostMessageW.Call(hwnd, wmNull, 0, 0)
	switch cmd {
	case cmdOpen:
		openBrowser(trayURL)
	case cmdQuit:
		go trayQuit()
	}
}

func trayQuit() {
	if b := busyWith(); b != "" {
		if msgBox("Quit SS1 Tool?", "SS1 Tool is still busy with "+b+".\n\nQuitting now stops it. Quit anyway?", mbYesNo|mbIconWarning|mbDefButton2) != idYes {
			return
		}
	}
	disconnect()
	appExit(0)
}

func trayLoop() {
	runtime.LockOSThread()
	hinst, _, _ := pGetModuleHandleW.Call(0)
	taskbarMsg, _, _ = pRegisterWindowMessageW.Call(uintptr(unsafe.Pointer(u16("TaskbarCreated"))))
	cls := u16("SS1ToolTray")
	wndProc := syscall.NewCallback(func(hwnd, msg, wparam, lparam uintptr) uintptr {
		switch {
		case msg == wmTray:
			switch lparam & 0xFFFF {
			case wmLButtonUp, wmLButtonDbl:
				openBrowser(trayURL)
			case wmRButtonUp, wmContextMenu:
				trayMenu(hwnd)
			}
			return 0
		case taskbarMsg != 0 && msg == taskbarMsg: // Explorer restarted: put the icon back
			trayAdd(false)
			return 0
		}
		r, _, _ := pDefWindowProcW.Call(hwnd, msg, wparam, lparam)
		return r
	})
	wc := wndClassEx{LpfnWndProc: wndProc, HInstance: hinst, LpszClassName: cls}
	wc.CbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))
	hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(u16("SS1 Tool"))), 0, 0, 0, 0, 0, 0, 0, hinst, 0)
	if hwnd == 0 {
		return
	}
	trayMu.Lock()
	trayNID = notifyIconData{HWnd: hwnd, UID: 1, UCallbackMessage: wmTray, HIcon: trayIcon()}
	trayNID.CbSize = uint32(unsafe.Sizeof(trayNID))
	trayMu.Unlock()
	trayAdd(true)
	onExit(trayRemove)
	var m winMsg
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			return
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
}

// edgePath finds Microsoft Edge, which every Windows 10/11 PC has, for the app window.
func edgePath() string {
	for _, env := range []string{"ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"} {
		if base := os.Getenv(env); base != "" {
			p := filepath.Join(base, "Microsoft", "Edge", "Application", "msedge.exe")
			if _, err := os.Stat(p); err == nil {
				return p
			}
		}
	}
	return ""
}

// openBrowser shows SS1 Tool in its own app window (Edge app mode), or in the default
// browser when that's chosen in About or Edge isn't available.
func openBrowser(url string) {
	cfgMu.Lock()
	mode := cfg.OpenIn
	cfgMu.Unlock()
	if mode != "browser" {
		if edge := edgePath(); edge != "" {
			c := exec.Command(edge, "--app="+url, "--window-size=1360,900")
			if c.Start() == nil {
				return
			}
		}
	}
	_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
}

func appWindowSupported() bool { return edgePath() != "" }
